# -*- coding: utf-8 -*-
# @Author: hana.boukricha
# @Date:   2021-03-06 22:29:27
# @Last Modified by:   hana.boukricha
# @Last Modified time: 2021-03-07 00:19:36

import setuptools
setuptools.setup()
